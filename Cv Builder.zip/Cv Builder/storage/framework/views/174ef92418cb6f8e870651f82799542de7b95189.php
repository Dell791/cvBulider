

<?php $__env->startSection('content'); ?>
     <h2>Cv Builder</h2>

    <form >
     <?php $__currentLoopData = $values; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $userdata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <div class="form-group row">
            <label for="name" class="col-sm-2 col-form-label">Name</label>
            <div class="col-sm-3">
                
               <?php echo e($userdata->name); ?>


            </div>
        </div>
        <div class="form-group row">
            <label for="fathername" class="col-sm-2 col-form-label">Father Name</label>
            <div class="col-sm-3">
                <?php echo e($userdata->fname); ?>

            </div>
        </div>
        <div class="form-group row" >
            <label for="universityname" class="col-sm-2 col-form-label">University Name</label>
            <div class="col-sm-2">
               <?php echo e($userdata->uname); ?>

            </div>
        </div>
        <div class="form-group row">
            <label for="dob" class="col-sm-2 col-form-label">Date of Birth</label>
            <div class="col-sm-3">
               <?php echo e($userdata->dob); ?>

            </div>
        </div>

        <div class="form-group row">
            <label for="education" class="col-sm-2 col-form-label">Education</label>
            <div class="col-sm-3">
               <?php echo e($userdata->education); ?>

            </div>
        </div>


        <div class="form-group row">
            <label for="project" class="col-sm-2 col-form-label">Projects</label>
            <div class="col-sm-3">
               <?php echo e($userdata->project); ?>

            </div>
        </div>

        <div class="form-group row">
            <label for="experience" class="col-sm-2 col-form-label">Experience</label>
            <div class="col-sm-3">
               <?php echo e($userdata->experience); ?>

            </div>
        </div>

        

        <div class="form-group row">
            <label for="address" class="col-sm-2 col-form-label">Address</label>
            <div class="col-sm-3" >
               <?php echo e($userdata->address); ?>

            </div>
        </div>

        <div class="form-group row">
            
            <div class="col-sm-3" style="margin-left: 40%; margin-top:-26%;">
                
                <img src="uploads\<?php echo e($userdata->image_name); ?>"  width="140" height="140">
            </div>
        </div>
        
       
        <div class="form-group row">
            <div class="offset-sm-2 col-sm-4">
                <a href="<?php echo e(url('generate-pdf')); ?>" class="btn btn-primary">Print</a>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Laravel\Cv Builder\resources\views/show.blade.php ENDPATH**/ ?>