

<?php $__env->startSection('content'); ?>
     <h2>Cv Builder</h2>

    <form >
     

        <div class="form-group row">
            <label for="titleid" class="col-sm-2 col-form-label">Name</label>
            <div class="col-sm-3" style="margin-left: 27%; border: 1px solid black;">
                <?php echo e($usercv->name); ?>

            </div>
        </div>
        <div class="form-group row">
            <label for="publisherid" class="col-sm-2 col-form-label">Father Name</label>
            <div class="col-sm-3" style="margin-left: 27%; border: 1px solid black;">
                <?php echo e($usercv->fname); ?>

            </div>
        </div>
        <div class="form-group row">
            <label for="releasedateid" class="col-sm-2 col-form-label">University Name</label>
            <div class="col-sm-3" style="margin-left: 27%; border: 1px solid black;">
                    <?php echo e($usercv->uname); ?>

            </div>
        </div>

        <div class="form-group row">
            <label for="releasedateid" class="col-sm-2 col-form-label">Date of Birth</label>
            <div class="col-sm-3" style="margin-left: 27%; border: 1px solid black;">
               <?php echo e($usercv->dob); ?>

            </div>
        </div>

        <div class="form-group row">
            <label for="releasedateid" class="col-sm-2 col-form-label">Experience</label>
            <div class="col-sm-3" style="margin-left: 27%; border: 1px solid black;">
               <?php echo e($usercv->experience); ?>

            </div>
        </div>

        <div class="form-group row">
            <label for="releasedateid" class="col-sm-2 col-form-label">Projects</label>
           <div class="col-sm-3" style="margin-left: 27%; border: 1px solid black;">
               <?php echo e($usercv->project); ?>

            </div>
        </div>

        <div class="form-group row">
            <label for="releasedateid" class="col-sm-2 col-form-label">Address</label>
            <div class="col-sm-3" style="margin-left: 27%; border: 1px solid black;">
               <?php echo e($usercv->address); ?>

            </div>
        </div>

        <div class="form-group row">
            
            <div class="col-sm-3" style="margin-left: 65%; margin-top:-42%;">
                
                <img src="uploads\<?php echo e($usercv->image_name); ?>"  width="140" height="140">
            </div>
        </div>

        </div>
        
    </form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Laravel\Cv Builder\resources\views/myPDF.blade.php ENDPATH**/ ?>