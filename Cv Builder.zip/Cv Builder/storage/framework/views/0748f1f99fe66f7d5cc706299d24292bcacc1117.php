

<?php $__env->startSection('content'); ?>

    <h2 style="text-align: center;">Cv Builder</h2>

    <form method="post" action="/cvbuilder" enctype="multipart/form-data">
        <?php echo e(csrf_field()); ?>

        <div class="form-group row">
            <label for="titleid" class="col-sm-2 col-form-label">Name</label>
            <div class="col-sm-3">
                <input name="name" type="text" class="form-control" id="name" placeholder="Name">
                 <?php if($errors->has('name')): ?>
                    <span class="text-danger">Name is required </span>
                <?php endif; ?>
            </div>
        </div>
        <div class="form-group row">
            <label for="publisherid" class="col-sm-2 col-form-label">Father Name</label>
            <div class="col-sm-3">
                <input name="fname" type="text" class="form-control" id="fname"
                       placeholder="Father Name">
                       <?php if($errors->has('fname')): ?>
                    <span class="text-danger"><?php echo e($errors->first('fname')); ?></span>
                <?php endif; ?>
            </div>
        </div>
        <div class="form-group row">
            <label for="releasedateid" class="col-sm-2 col-form-label">University Name</label>
            <div class="col-sm-3">
                <input name="uname" type="text" class="form-control" id="uname"
                       placeholder="University Name">
                        <?php if($errors->has('uname')): ?>
                   <span class="text-danger"><?php echo e($errors->first('uname')); ?></span>
                <?php endif; ?>
            </div>
        </div>

         <div class="form-group row">
            <label for="publisherid" class="col-sm-2 col-form-label">Date of Birth</label>
            <div class="col-sm-3">         
                <input type="date" name="date" id="date" class="form-control" style="width: 100%; display: inline;" >
            </div>
        </div>

        <div class="form-group row">
            <label for="publisherid" class="col-sm-2 col-form-label">Education</label>
            <div class="col-sm-3">         
                <input type="text" name="education" id="education" class="form-control" placeholder="Education">
            </div>
        </div>

        <div class="form-group row">
            <label for="publisherid" class="col-sm-2 col-form-label">Projects</label>
            <div class="col-sm-3">         
                <input type="text" name="project" id="project" class="form-control" placeholder="Project">
            </div>
        </div>
        <div class="form-group row">
            <label for="publisherid" class="col-sm-2 col-form-label">Experience</label>
            <div class="col-sm-3">         
                <input type="text" name="experience" id="experience" class="form-control" placeholder="Experience">
            </div>
        </div>

        <div class="form-group row" style="margin-top:-12%; margin-left: 43%;">
            <label for="publisherid" class="col-sm-2 col-form-label">Address</label>
            <div class="col-sm-6">         
                <textarea name="address" id="address" class="form-control" placeholder="Address"  rows="6" cols="55"></textarea>
            </div>
        </div>


        <?php if($message = Session::get('success')): ?>
                <div class="alert alert-success">
                    <strong><?php echo e($message); ?></strong>
                </div>
            <?php endif; ?>

            <?php if(count($errors) > 0): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

                 

            <div class="col-sm-3" style="margin-left:54%; margin-top: -18%;">
                <input type="file" name="imageFile[]" class="custom-file-input" id="images" multiple="multiple">
                <label class="custom-file-label" for="images">Select Image</label>
            </div>
       
        <div class="form-group row">
            <div class="offset-sm-2 col-sm-4" style="margin-top: 15%;">
                <button type="submit" class="btn btn-primary">Submit</button>
            </div>
        </div>
    </form>

<?php $__env->stopSection(); ?>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script>
        $(function() {
        // Multiple images preview with JavaScript
        var multiImgPreview = function(input, imgPreviewPlaceholder) {

            if (input.files) {
                var filesAmount = input.files.length;

                for (i = 0; i < filesAmount; i++) {
                    var reader = new FileReader();

                    reader.onload = function(event) {
                        $($.parseHTML('<img>')).attr('src', event.target.result).appendTo(imgPreviewPlaceholder);
                    }

                    reader.readAsDataURL(input.files[i]);
                }
            }

        };

        $('#images').on('change', function() {
            multiImgPreview(this, 'div.imgPreview');
        });
        });    
    </script>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Laravel\Cv Builder\resources\views/cvbuilder.blade.php ENDPATH**/ ?>