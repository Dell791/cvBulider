@extends('layouts.master')

@section('content')
     <h2>Cv Builder</h2>

    <form >
     @foreach($values as $userdata)

        <div class="form-group row">
            <label for="name" class="col-sm-2 col-form-label">Name</label>
            <div class="col-sm-3">
                
               {{ $userdata->name }}

            </div>
        </div>
        <div class="form-group row">
            <label for="fathername" class="col-sm-2 col-form-label">Father Name</label>
            <div class="col-sm-3">
                {{ $userdata->fname }}
            </div>
        </div>
        <div class="form-group row" >
            <label for="universityname" class="col-sm-2 col-form-label">University Name</label>
            <div class="col-sm-2">
               {{ $userdata->uname }}
            </div>
        </div>
        <div class="form-group row">
            <label for="dob" class="col-sm-2 col-form-label">Date of Birth</label>
            <div class="col-sm-3">
               {{ $userdata->dob }}
            </div>
        </div>

        <div class="form-group row">
            <label for="education" class="col-sm-2 col-form-label">Education</label>
            <div class="col-sm-3">
               {{ $userdata->education }}
            </div>
        </div>


        <div class="form-group row">
            <label for="project" class="col-sm-2 col-form-label">Projects</label>
            <div class="col-sm-3">
               {{ $userdata->project }}
            </div>
        </div>

        <div class="form-group row">
            <label for="experience" class="col-sm-2 col-form-label">Experience</label>
            <div class="col-sm-3">
               {{ $userdata->experience }}
            </div>
        </div>

        

        <div class="form-group row">
            <label for="address" class="col-sm-2 col-form-label">Address</label>
            <div class="col-sm-3" >
               {{ $userdata->address }}
            </div>
        </div>

        <div class="form-group row">
            
            <div class="col-sm-3" style="margin-left: 40%; margin-top:-26%;">
                
                <img src="uploads\{{ $userdata->image_name }}"  width="140" height="140">
            </div>
        </div>
        
       
        <div class="form-group row">
            <div class="offset-sm-2 col-sm-4">
                <a href="{{url('generate-pdf')}}" class="btn btn-primary">Print</a>
            </div>
        </div>
        @endforeach
    </form>

@endsection