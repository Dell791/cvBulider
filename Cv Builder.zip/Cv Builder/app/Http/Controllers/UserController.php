<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\cvBuilder;

use PDF;

use Session;

class UserController extends Controller
{
    protected $data = [];
    public function index(Request $request)
    {
        $alluser = cvBuilder::all();
        return view('cvbuilder.index', ['alldata' => $alluser]);
    }

    public function create()
    {
        // return 'it works';

        return view('cvbuilder');
    }

    public function generatePDF(Request $data)
    {

        foreach(Session::get('data') as $users)
        {   
            foreach($users as $user)
            {

                $pdf = PDF::loadView('myPDF', ['usercv' => $user]);
    
                return $pdf->download('CvBuilder.pdf');
            }
            
        }
    }

    public function store(Request $request)
    {

        $request->validate(
            [
                'name' => 'required',
                'fname' => 'required',
                'uname' => 'required',
                'imageFile' => 'required',
        'imageFile.*' => 'mimes:jpeg,jpg,png,gif,csv,txt,pdf|max:2048'
            ], 
            [
                'name.required' => 'Name is required',
                'fname.required' => 'Father Name is required',
                'uname.required' => 'University Name is required'
            ]
          );

        if($request->hasfile('imageFile')) 
        {
            foreach($request->file('imageFile') as $file)
            {
                $name = $file->getClientOriginalName();
                $file->move(public_path().'/uploads/', $name);  
                $imgData[] = $name;  
            }

           foreach($imgData as $img)
           {
                $datacv = new cvBuilder;
                $datacv->image_name = $img;
                $datacv->name = request('name');
                $datacv->fname = request('fname');
                $datacv->uname = request('uname');
                $datacv->dob = request('date');
                $datacv->education = request('education');
                $datacv->project = request('project');
                $datacv->experience = request('experience');
                $datacv->address = request('address');

                $datacv->save();

                $data['values'] = [$datacv];

                Session::put('data', $data);

        

                return view('show' , $data);
            }

        
        }

    }


}
