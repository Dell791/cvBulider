<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\UserController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/cvbuilder', [UserController::class, 'index']);

Route::get('cvbuilder/create', 'UserController@create');

Route::post('cvbuilder', 'UserController@store');

Route::get('generate-pdf', [UserController::class, 'generatePDF']);

// Route::get('/image-upload', [UserController::class, 'createForm']);

// Route::post('/image-upload', [UserController::class, 'fileUpload'])->name('imageUpload');
